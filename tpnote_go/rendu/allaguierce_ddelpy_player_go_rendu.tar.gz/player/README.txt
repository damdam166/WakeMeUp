# Player of GO

### Credits

- Alessandre LAGUIERCE

- Damien DELPY



## myPlayer.py

We used `pytorch` to load our heuristic model. Nothing more.


### EXEMPLES DE LIGNES DE COMMANDES:

python3 localGame.py
--> Va lancer un match myPlayer.py contre myPlayer.py

python3 namedGame.py myPlayer randomPlayer
--> Va lancer un match entre votre joueur (NOIRS) et le randomPlayer
 (BLANC)

 python3 namedGame gnugoPlayer myPlayer
 --> gnugo (level 0) contre votre joueur (très dur à battre)

### EOF

